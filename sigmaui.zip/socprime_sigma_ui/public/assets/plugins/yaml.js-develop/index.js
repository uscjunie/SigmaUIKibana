
var Yaml = require('./lib/Yaml');
module.exports = Yaml;
