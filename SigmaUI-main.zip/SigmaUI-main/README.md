# SigmaUI | By SOC Prime | Fixed by Prithvi Boinpally
A working/fixed version of SOCPrime's SIGMA-UI

**INSTALL GUIDE:**

_**Prerequisites**_:   
**0.** An AWS EC2 instance running Ubunutu.   
**1.** Both Python 2.7 and Python 3.6+ are required.   
**2.** Install `pip` for both versions of Python. You can invoke the Python 2.X version of pip via `pip` and the Python 3.X version of pip via `pip3`.   
**3.** **Important:** For both versions of Python, install ruamel.yaml system wide. 
**4a.** For Python 2.X, ensure that the Elasticsearch _python library_ is installed by checking `pip list`. If not, simply`pip install elasticsearch`.
**4b.** For Python 3.X, ensure that PyYAML is installed with a version >= 3.11 via `pip3 list`.   
**5.** Now, install the ELK (Elasticsearch, Logstash, Kibana) stack. **All of the 3 components must be of the same version number.** This guide uses ELK version 7.5.2. This is because the way plugins for Kibana were designed changed in future versions (7.10+ I believe?) which would break this plugin as it was built for Kibana versions prior to that change. _I would recommend using_ `dpkg` _if you're installing this on an Ubuntu EC2 instance._  
**6.** Enable and then start the ELK via `sudo systemctl enable elasticsearch` and `sudo systemctl start elasticsearch`. Do the same for `logstash` and `kibana`.   
**7.** Configure Kibana to the correct port and IP address (for AWS EC2 installations) by modifying the `kibana.yml` file found in `/etc/kibana/kibana.yml`. The `server.host:` field should be set to the **private IP address** of the EC2 running the ELK stack.   
**8.** Launch Kibana in your browser and verify that connecting to it over port 5601 works. You should connect to the EC2 via it's **[public IP address]:5601** in your browser bar. If everything works and you can see the Kibana dashboard, we are finally ready to install the SigmaUI plugin.   

**_Plugin Installation:_**   
**1.** Copy the folder named `socprime_sigma_ui` (which can be found inside the `sigma_ui_1.2.5/kibana` folder in this repo) to `/usr/share/kibana/plugins`. The resulting file structure should be: `/usr/share/kibana/plugins/socprime_sigma_ui`.   
**1 (Alternate Method).** You can also install the plugin via Kibana's plugin installer command, which requires the `sigma_ui_1.2.5` folder in this repo to be zipped up, renamed to `sigma-ui-1.2.5.zip` and transferred to the EC2 with the ELK stack on it. Use `/usr/share/kibana/bin/./kibana-plugin install file:///PATH_TO_FILE/sigma-ui-xxxxx.zip` to install the plugin.   
**2.** You must now restart Kibana via the `sudo systemctl stop kibana` and `sudo systemctl start kibana` commands.  Note: If after restarting Kibana you don’t see any changes, go to /usr/share/kibana/optimize folder. Delete all files in this folder including subfolders. Then restart Kibana using the aforementioned commands. This will make Kibana refresh its cache.   
**3.** You should now be able to view the SigmaUI in the Kibana interface. It should appear as a small shortcut icon on the left sidebar. At this point, the UI portion is functional, but the rule conversion component is not. We still have a few more steps.   
**4.** Now, go to the DevTools Console in Kibana. Here, we will import the index templates provided by SOCPrime that map to the SIGMA Rule Format. To import the index template, simply copy paste each "POST {}" request within `index_template_sigma_ui.txt` from within this repo into Kibana's DevTool Console and click the "Send Request" button (a small green triangle icon in the upper middle of the console). If this worked correctly you should see the two index templates `sui_config` and `sui_sigma_doc` under the Index Management settings of Kibana (at Management/Elasticsearch/Index Management/Index Templates). This UI path might be different on different versions of Kibana compared to v7.5.2.   
**5.** Next, copy the `ELK_import_export` folder to anywhere on the EC2, preferably a sensible location like the home directory (`cd ~`). Then run `python /PATH_TO_FILE/ELK_import_export/import_es_index.py`. Indices will be created and filled with Sigma rules.   
**6.** Next, copy the `scripts_tdm_api` folder to `/opt/scripts/`. Then `cd` into `/opt/scripts/scripts_tdm_api` and run `pip install -Ur requirements.txt`   
**7.** Lastly, you will need to configure the paths within `/usr/share/kibana/plugins/socprime_sigma_ui/config/common.json`. If you followed the path recommendations I provided, `common.json` should require _zero_ changes. If not, the paths are set as follows by default, change them to your appropriate paths: 
```
{
  "debug": true,
  "max_upload_period_in_month": 2,
  "python_path": "/usr/bin/python3",
  "tdm_api_integration_tool_path": "/opt/scripts/script_tdm_api/tdm_api_for_sigma_ui.py",
  "tpm_sigma_folder_path": "/opt/scripts/script_tdm_api/sigmas"
}
```
**8.** Restart Kibana once again with the `sudo systemctl stop kibana` and `sudo systemctl start kibana` commands. 

**At this point, the plugin should be fully functional.** If the conversion of rules to other formats (via the Export button in the SigmaUI) doesn't seem to be working (you'll get an error saying "Something went wrong."), try deleting the contents of the `/usr/share/kibana/optimize/` folder and restarting Kibana again, just like in step 2 of the "Plugin Installation" section. If this still doesn't work, refer to the "**Debugging**" section of the Readme.   


**ADDITIONAL INFORMATION:**   
   
The TDM API script gets new Sigma rules published at TDM using an API. The script uploads Sigma rules with the latest updated date in the `sui_sigma_doc` index. If the time range is greater than the values specified in `max_upload_period_in_month`, then it uses the `max_upload_period_in_month` value.   
This script gets all available Sigma rules for your Company registered at TDM.   
The script uses a temporary directory for storing data received from the TDM API. The path can be specified in the `tpm_sigma_folder_path` value. The received data is saved in the file in `*.json` format.   
Meaning of other settings:

     * "debug": true 
     > Allow sending bugs/errors from the back end
     
     * "python_path": "/usr/bin/python3"
     > Path to the Python script
     
     * "tdm_api_integration_tool_path": "/opt/scripts/script_tdm_api/tdm_api_integration_tool.py"
     > Path to the script for updating the TDM Sigma rules using the TDM API

**DEBUGGING:**   

Run `sudo systemctl status kibana` and check to see if any errors show up. If you see a permission denied error, the culprit is usually the following two files: `sigma_converter.log` and `tmp_sigma.txt` located at `/usr/share/kibana/plugins/socprime_sigma_ui/server/translation_script/sigma/`. The issue is that they have insufficient permissions granted by default so writing to them isn't possible, causing the plugin to fail when writing the currently open rule (in the SigmaUI editor) to `tmp_sigma.txt` for conversion/export purposes. The `sigma_converter.log` file not having sufficient permisisons is another issue, as errors cannot be written to the log for us to even see what is wrong!   
**In order to fix this**, modify the permissions of the two files mentioned above via `chmod 777` to allow full read/write access to the file and allow it to be written to by the plugin.  
If you still have problems with the "Export" functionality of the SigmaUI plugin, open the `sigma_converter.log` file and look at any error messages that exist there. If the issue is a missing dependancy/module missing error like `ruamel.yaml`, ensure that you correctly `pip install`'ed the package. Research online on how to install Python packages systemwide to ensure that Python code can access those libraries.   
_Once you fix these issues, the plugin should definitely work._
